
public class Main1 {
    public int findSingleElement(int[] arr) {
        int result = 0;

        for (int i = 0; i < arr.length; i += 2) {
            if (i == arr.length - 1 || arr[i] != arr[i + 1]) {
                result = arr[i];
                break;
            }
        }

        return result;
    }
}
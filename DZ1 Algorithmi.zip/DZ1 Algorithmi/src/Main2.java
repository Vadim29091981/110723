public class Main2 {
    public int findSingleElement(int[] arr) {
        int left = 0;
        int right = arr.length - 1;

        while (left < right) {
            int mid = left + (right - left) / 2;

            // Убедимся, что mid всегда четное число
            if (mid % 2 == 1) {
                mid--;
            }

            if (arr[mid] != arr[mid + 1]) {
                right = mid;
            } else {
                left = mid + 2;
            }
        }

        return arr[left];
    }
    /*Оба метода будут работать для отсортированного массива, где все элементы встречаются дважды, кроме одного, который встречается один раз.
*/









}

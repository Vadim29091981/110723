package CommandLinePar;

import java.util.ArrayList;
import java.util.List;

public class CommandLineParser {
    public static class SortSettings {
        private boolean ascending = true; // По умолчанию сортируем по возрастанию
        private String dataType;
        private String outputFile;
        private List<String> inputFiles;

        public SortSettings(boolean ascending, String dataType, String outputFile, List<String> inputFiles) {
            this.ascending = ascending;
            this.dataType = dataType;
            this.outputFile = outputFile;
            this.inputFiles = inputFiles;
        }

        public boolean isAscending() {
            return ascending;
        }

        public String getDataType() {
            return dataType;
        }

        public String getOutputFile() {
            return outputFile;
        }

        public List<String> getInputFiles() {
            return inputFiles;
        }
    }

    public SortSettings parse(String[] args) {
        boolean ascending = true; // По умолчанию сортируем по возрастанию
        String dataType = null;
        String outputFile = null;
        List<String> inputFiles = new ArrayList<>();

        if (args.length < 3) {
            printUsage();
            System.exit(1);
        }

        int i = 0;

        if (args[i].equals("-a")) {
            ascending = true;
            i++;
        } else if (args[i].equals("-d")) {
            ascending = false;
            i++;
        }

        if (args[i].equals("-s") || args[i].equals("-i")) {
            dataType = args[i];
            i++;
        } else {
            printUsage();
            System.exit(1);
        }

        outputFile = args[i];
        i++;

        while (i < args.length) {
            inputFiles.add(args[i]);
            i++;
        }

        return new SortSettings(ascending, dataType, outputFile, inputFiles);
    }

    private void printUsage() {
        System.out.println("Использование: sort-it.exe [-a|-d] (-s|-i) output_file input_file1 [input_file2 ...]");
    }

    public static void main(String[] args) {
        CommandLineParser parser = new CommandLineParser();
        SortSettings settings = parser.parse(args);

        System.out.println("Режим сортировки: " + (settings.isAscending() ? "по возрастанию" : "по убыванию"));
        System.out.println("Тип данных: " + settings.getDataType());
        System.out.println("Имя выходного файла: " + settings.getOutputFile());
        System.out.println("Входные файлы: " + settings.getInputFiles());
    }
}
package CommandLinePar;

import java.util.List;

public class SortSettings {
    private boolean ascending = true; // По умолчанию сортируем по возрастанию
    private String dataType;
    private String outputFile;
    private List<String> inputFiles;

    public SortSettings(String dataType, String outputFile, List<String> inputFiles) {
        this.dataType = dataType;
        this.outputFile = outputFile;
        this.inputFiles = inputFiles;
    }

    public void setAscending(boolean ascending) {
        this.ascending = ascending;
    }

    public boolean isAscending() {
        return ascending;
    }

    public String getDataType() {
        return dataType;
    }

    public String getOutputFile() {
        return outputFile;
    }

    public List<String> getInputFiles() {
        return inputFiles;
    }
}

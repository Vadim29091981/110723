package CommandLinePar;

import java.text.ParseException;

public class Main {
    public static void main(String[] args) {
        CommandLineParser parser = new CommandLineParser();
        CommandLineParser.SortSettings settings = parser.parse(args);

        System.out.println("Режим сортировки: " + (settings.isAscending() ? "по возрастанию" : "по убыванию"));
        System.out.println("Тип данных: " + settings.getDataType());
        System.out.println("Имя выходного файла: " + settings.getOutputFile());
        System.out.println("Входные файлы: " + settings.getInputFiles());

        // Здесь вы можете использовать settings для выполнения сортировки или другой логики

    }
}